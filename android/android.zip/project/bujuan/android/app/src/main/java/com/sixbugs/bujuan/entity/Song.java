package com.sixbugs.bujuan.entity;


public class Song {
    private String name;
    private String id;
    private String picUrl;
    private String singer;

    public Song() {
    }

    public Song(String name, String id, String picUrl, String singer) {
        this.name = name;
        this.id = id;
        this.picUrl = picUrl;
        this.singer = singer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }
}
