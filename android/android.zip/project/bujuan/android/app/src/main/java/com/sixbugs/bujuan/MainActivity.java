package com.sixbugs.bujuan;

import android.os.Bundle;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.lzx.starrysky.StarrySky;
import com.lzx.starrysky.control.OnPlayerEventListener;
import com.lzx.starrysky.provider.SongInfo;
import com.sixbugs.bujuan.entity.Song;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import io.flutter.app.FlutterActivity;
import io.flutter.plugins.GeneratedPluginRegistrant;

public class MainActivity extends FlutterActivity implements OnPlayerEventListener {
    private BuJuanMusicListenPlugin buJuanMusicListenPlugin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        GeneratedPluginRegistrant.registerWith(this);
        StarrySky.with().addPlayerEventListener(this);
        BujuanMusicPlugin.registerWith(this.registrarFor(BujuanMusicPlugin.CHANNEL));
        buJuanMusicListenPlugin = BuJuanMusicListenPlugin.registerWith(this.registrarFor(BuJuanMusicListenPlugin.CHANNEL));
    }


    @Override
    public void onBuffering() {

    }

    @Override
    public void onError(int i, @NotNull String s) {
        StarrySky.with().skipToNext();
    }

    @Override
    public void onMusicSwitch(@NotNull SongInfo songInfo) {
        Song song = new Song();
        song.setId(songInfo.getSongId());
        song.setName(songInfo.getSongName());
        song.setSinger(songInfo.getArtist());
        song.setPicUrl(songInfo.getAlbumCover());
        buJuanMusicListenPlugin.eventSink.success(JSON.toJSONString(song));
    }

    @Override
    public void onPlayCompletion(@NotNull SongInfo songInfo) {
        buJuanMusicListenPlugin.eventSink.success("completion");
    }

    @Override
    public void onPlayerPause() {
        buJuanMusicListenPlugin.eventSink.success("pause");
    }

    @Override
    public void onPlayerStart() {
        buJuanMusicListenPlugin.eventSink.success("start");
    }

    @Override
    public void onPlayerStop() {
        buJuanMusicListenPlugin.eventSink.success("stop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        StarrySky.with().removePlayerEventListener(this);
        StarrySky.with().stopMusic();
    }
}
