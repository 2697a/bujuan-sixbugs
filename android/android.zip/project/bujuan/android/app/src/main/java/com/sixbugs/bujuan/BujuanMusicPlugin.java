package com.sixbugs.bujuan;


import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSONArray;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry;

import com.lzx.starrysky.StarrySky;
import com.lzx.starrysky.provider.SongInfo;
import com.sixbugs.bujuan.entity.Song;


import java.util.ArrayList;
import java.util.List;

/**
 * BujuanMusicPlugin
 */
public class BujuanMusicPlugin implements MethodCallHandler {
    /**
     * 插件标识
     */
    public static String CHANNEL = "music_plugin";

    private static MethodChannel channel;

    private static MainActivity activity;

    public static void registerWith(PluginRegistry.Registrar registrar) {
        channel = new MethodChannel(registrar.messenger(), CHANNEL);
        BujuanMusicPlugin instance = new BujuanMusicPlugin();
        channel.setMethodCallHandler(instance);
        activity = (MainActivity) registrar.activity();
    }

    @Override
    public void onMethodCall(MethodCall methodCall, Result result) {
        if (methodCall.method.equals("songInfo")) {
            result.success(updateSongList(methodCall));
        } else if (methodCall.method.equals("control")) {
            String task = methodCall.argument("task");
            if (task != null)
                if (task.equals("play"))
                    StarrySky.with().playMusic();
                else if (task.equals("pause"))
                    StarrySky.with().pauseMusic();
                else if (task.equals("next"))
                    StarrySky.with().skipToNext();

        } else if (methodCall.method.equals("local_music")) {
            List<SongInfo> songInfos = StarrySky.with().querySongInfoInLocal();
            for (SongInfo songInfo : songInfos) {
                Log.d("", "onMethodCall: =======" + songInfo.getAlbumHDCover());
            }
        } else {
            result.notImplemented();
        }
    }

    ///更新歌曲列表并播放
    private String updateSongList(MethodCall methodCall) {
        String data = methodCall.argument("data");
        if (data != null && !TextUtils.isEmpty(data)) {
            List<Song> songs = JSONArray.parseArray(data, Song.class);
            List<SongInfo> songInfos = new ArrayList<>();
            if (songs != null)
                for (Song song : songs) {
                    if (song.getId()!=null) {
                        SongInfo songInfo = new SongInfo();
                        songInfo.setSongName(song.getName() == null ? "" : song.getName());
                        songInfo.setAlbumCover(song.getPicUrl()==null?"":song.getPicUrl());
                        songInfo.setSongId(song.getId()==null?"":song.getId());
                        songInfo.setArtist(song.getSinger()==null?"":song.getSinger());
                        songInfo.setSongUrl("");
                        songInfos.add(songInfo);
                    }
                }
            StarrySky.with().updatePlayList(songInfos.subList(1, songInfos.size()));
            StarrySky.with().playMusicByInfo(songInfos.get(0));
        }
        return "success";
    }
}
