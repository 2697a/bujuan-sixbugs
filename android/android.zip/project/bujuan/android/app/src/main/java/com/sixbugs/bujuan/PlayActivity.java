package com.sixbugs.bujuan;


import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.fastjson.JSONArray;
import com.bumptech.glide.Glide;
import com.lzx.starrysky.StarrySky;
import com.lzx.starrysky.control.OnPlayerEventListener;
import com.lzx.starrysky.provider.SongInfo;
import com.sixbugs.bujuan.entity.Song;
import com.sixbugs.bujuan.imageloader.ActivityUtils;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class PlayActivity extends AppCompatActivity implements OnPlayerEventListener {

    private ImageView songImg;
    private TextView songName;
    private TextView songSinger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityUtils.makeStatusBarTransparent(this);
        setContentView(R.layout.activity_play);
        songImg = findViewById(R.id.songPic);
        songName = findViewById(R.id.songName);
        songSinger = findViewById(R.id.songSinger);
        StarrySky.with().addPlayerEventListener(this);
        initData();
        SongInfo nowPlayingSongInfo = StarrySky.with().getNowPlayingSongInfo();
        if (nowPlayingSongInfo != null)
            setSongInfo(nowPlayingSongInfo);
    }

    private void initData() {
        String info = getIntent().getStringExtra("info");
        if (info != null && !TextUtils.isEmpty(info)) {
            List<Song> songs = JSONArray.parseArray(info, Song.class);
            List<SongInfo> songInfos = new ArrayList<>();
            if (songs != null)
                for (Song song : songs) {
                    SongInfo songInfo = new SongInfo();
                    songInfo.setSongName(song.getName());
                    songInfo.setAlbumCover(song.getPicUrl());
                    songInfo.setSongId(song.getId());
                    songInfo.setArtist(song.getSinger());
                    songInfo.setSongUrl("");
                    songInfos.add(songInfo);
                }
            StarrySky.with().updatePlayList(songInfos.subList(1, songInfos.size()));
            StarrySky.with().playMusicByInfo(songInfos.get(0));
        }
    }

    private void setSongInfo(SongInfo nowPlayingSongInfo) {
        Glide.with(this).load(nowPlayingSongInfo.getAlbumCover()).into(songImg);
        songName.setText(nowPlayingSongInfo.getSongName());
        songSinger.setText(nowPlayingSongInfo.getArtist());
    }

    @Override
    public void onBuffering() {

    }

    @Override
    public void onError(int i, @NotNull String s) {

    }

    @Override
    public void onMusicSwitch(@NotNull SongInfo songInfo) {
        setSongInfo(songInfo);
    }

    @Override
    public void onPlayCompletion(@NotNull SongInfo songInfo) {

    }

    @Override
    public void onPlayerPause() {

    }

    @Override
    public void onPlayerStart() {

    }

    @Override
    public void onPlayerStop() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        StarrySky.with().removePlayerEventListener(this);
    }
}
